<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Online Student Attendance Management System</title>
	<link rel="stylesheet" type="text/css" href="inc/bootstrap.min.css" media="screen">   
    <script type="text/javascript" src="inc/jquery.min.js"></script>
     <script type="text/javascript" src="inc/bootstrap.min.js"></script>
</head>
<body>


<div class="container">
	<div class="well text-center">
		<h1>Online Attendance Management System</h1>
		
	</div>
	
</div>
